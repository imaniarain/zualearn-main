<div class="pull-right">
		<footer>
           <p>Programmed by: Imaniar Baidury Fatiha S1TI-A</p>
        <footer>
</div>