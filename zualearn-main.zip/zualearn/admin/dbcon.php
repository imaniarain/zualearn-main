<?php
$conn = mysqli_connect('localhost','root','','zualearn') or die(mysqli_error());
?>